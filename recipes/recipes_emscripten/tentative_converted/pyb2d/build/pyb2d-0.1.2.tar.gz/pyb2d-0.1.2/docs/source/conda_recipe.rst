

Conda Recipe
=================

The recipe subfolder contains all the code related 
to the conda recipe

::

    project
    ├── ...
    ├── recipe          
    │   ├── bld.bat
    │   ├── build.sh
    │   ├── meta.tml
    ├── ...
