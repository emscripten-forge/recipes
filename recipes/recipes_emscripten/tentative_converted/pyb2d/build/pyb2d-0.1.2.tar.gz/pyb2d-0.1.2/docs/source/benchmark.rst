Benchmark
=========


We use gbench_ to create a benchmark for the C++ code.


The benchmark subfolder contains all the code related 
to the benchmarks.
In main.cpp the actual benchmarks are implemented.

::

    pybox2d
    ├── ...
    ├── benchmark          
    │   ├── main.cpp
    ├── ...


.. _gbench: https://github.com/google/benchmark
