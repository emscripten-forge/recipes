
def test_import_pyb2d():
    import b2d
    import b2d.testbed
    