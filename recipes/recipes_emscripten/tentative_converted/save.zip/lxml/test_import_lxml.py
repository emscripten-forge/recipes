
def test_import_lxml():
    import lxml
    import lxml.etree
    import lxml.objectify
    