
def test_import_yt():
    import yt
    