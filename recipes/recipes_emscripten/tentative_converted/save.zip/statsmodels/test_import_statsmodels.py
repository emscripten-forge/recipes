
def test_import_statsmodels():
    import statsmodels
    import statsmodels.api
    