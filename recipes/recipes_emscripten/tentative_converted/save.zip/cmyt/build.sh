#!/bin/bash
${PYTHON} -m pip  install .
