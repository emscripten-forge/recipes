
def test_import_cmyt():
    import cmyt
    