
def test_import_pywavelets():
    import pywt
    