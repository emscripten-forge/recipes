
def test_import_scikit-image():
    import skimage
    