#!/bin/bash

pip install pythran
pip install --upgrade pythran -t $PYODIDE_ROOT/packages/.artifacts/
