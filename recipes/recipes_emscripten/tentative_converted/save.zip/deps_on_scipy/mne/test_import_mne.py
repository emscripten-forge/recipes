
def test_import_mne():
    import mne
    