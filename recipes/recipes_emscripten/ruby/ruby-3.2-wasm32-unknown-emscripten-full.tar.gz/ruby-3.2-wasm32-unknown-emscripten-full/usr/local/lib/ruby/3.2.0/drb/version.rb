module DRb
  VERSION = "2.1.1"
end
